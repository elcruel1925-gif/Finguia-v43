# Finguia v43 Android

Proyecto Android preparado a partir de `FinGuia_AI_MVP_v43_IA_Real.html`.

- App ID: `com.finguia.app`
- Version code: `43`
- Version name: `4.3`
- Arquitectura: WebView + HTML local
- Internet requerido: sí (Supabase)

Para generar el APK se necesita un entorno Android/Gradle (por ejemplo Android Studio o un build cloud compatible).
